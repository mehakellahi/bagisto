<?php

return [
    'name'    => 'Webkul Bagisto Shop',
    'version' => '0.0.1',
];
